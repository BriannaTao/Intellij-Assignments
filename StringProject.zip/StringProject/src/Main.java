import java.util.Scanner;
public class Main {
    public static void main(String[] args) {


        Scanner numVar = new Scanner(System.in);
        System.out.println("Type a number.");

        int yournum = numVar.nextInt();

        Scanner userVar = new Scanner(System.in);
        System.out.println("What is your name ?");

        String yourname = userVar.nextLine();
        System.out.println(yourname.substring(0, yournum));

        int namelen = yourname.length();
        System.out.println(yourname.substring(namelen - yournum));



        Scanner sentVar = new Scanner(System.in);
        System.out.println("Type a sentence.");


        String yoursent = sentVar.nextLine();


        int sentlen = yoursent.length();


        int sentInd = yoursent.indexOf(" ");


        System.out.println(yoursent.substring(0, sentInd));


    }
}