import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
        System.out.print("How much are you willing to pay for a movie?");
        double cost = scan.nextDouble();

        System.out.println("How many star does a movie need to receive that would make interested in?");
        int rating = scan.nextInt();

        if ( cost < 5.00 ){
            System.out.println("You are interested");
        }
        else if (cost > 12.00 && rating == 5 ) {
            System.out.println(" You are sort-of interested");
        }
        else if (cost < 12.00 && rating == 5){
            System.out.println(" You are sort-of interested. ");
        }
        else if ( 5.00 < cost && cost <11.99 && 1 < rating && rating ==4  ){
            System.out.println("You are sort-of interested.");
        }
        else {
            System.out.println("You are not interested.");
        }




    }
}