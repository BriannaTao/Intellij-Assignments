public class Movie {

    private double cost;
    private int rating;

    public void seeMovie(double costParameter, int ratingParameter){
        cost = costParameter;
        rating = ratingParameter;

        if ( cost < 5.00 ){
            System.out.println("You like bargains. Any movie that costs less than $5.00 is one that you want to see very much.");
        }
        else if (cost > 12.00 && rating == 5 ) {
            System.out.println(" You dislike expensive movies. You are not interested in seeing any movies that cost $12.00 or more, unless it got 5 stars (and even then, you are only sort-of interested).");
        }
        else if (cost < 12.00 && rating == 5){
            System.out.println(" You like quality. You are very interested in seeing 5-star movies that cost under $12.00.");
        }
        else if ( 5.00 < cost && cost <11.99 && 1 < rating && rating ==4  ){
            System.out.println("You are sort-of interested in seeing 5-star movies that cost under $12.00.");
        }
        else {
            System.out.println("You are not interested in seeing any other movies.");
        }
    }
}
