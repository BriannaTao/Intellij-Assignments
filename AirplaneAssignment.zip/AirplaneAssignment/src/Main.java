import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        AirplaneClass Airplane1 = new AirplaneClass();
        AirplaneClass Airplane2 = new AirplaneClass("AAA02", 15.8, 128, 3000);

        Scanner scan  = new Scanner(System.in);
        System.out.println("What are the call-signs,distance, direction, and altitude of Airplane 3?");
        String newcallsign = scan.nextLine();
        double newdistance = scan.nextDouble();
        int newdirection = scan.nextInt();
        int newaltitude = scan.nextInt();
        //IP
        System.out.println(Airplane1.ToString());
        System.out.println(Airplane2.ToString());
        System.out.println(Airplane3.ToString());
        //ID
        System.out.println("The distance between Airplane 1 and Airplane 2 is"+Airplane1.distanceTo(Airplane2.getDistance));
        System.out.println("The distance between Airplane 1 and Airplane 3 is"+Airplane1.distanceTo(newdistance));
        System.out.println("The distance between Airplane 2 and Airplane 3 is"+Airplane2.distanceTo(newdistance));
        //IHD
        System.out.println("The difference in height between Airplane 1 and Airplane 2 is"+Math.abs(Airplane1.getAltitude-Airplane2.getAltitude));
        System.out.println("The difference in height between Airplane 1 and Airplane 3 is"+Math.abs(Airplane1.getAltitude-Airplane3.getAltitude));
        System.out.println("The difference in height between Airplane 2 and Airplane 3 is"+Math.abs(Airplane2.getAltitude-Airplane3.getAltitude));
        //NP
        System.out.println(Airplane1.ToString());
        System.out.println(Airplane2.ToString());
        System.out.println(Airplane3.ToString());

        //ND
        System.out.println("The distance between Airplane 1 and Airplane 2 is"+Airplane1.distanceTo(Airplane2.getDistance));
        System.out.println("The distance between Airplane 1 and Airplane 3 is"+Airplane1.distanceTo(newdistance));
        System.out.println("The distance between Airplane 2 and Airplane 3 is"+Airplane2.distanceTo(newdistance));
        // NHD
        System.out.println("The difference in height between Airplane 1 and Airplane 2 is"+Math.abs(Airplane1.getAltitude-Airplane2.getAltitude));
        System.out.println("The difference in height between Airplane 1 and Airplane 3 is"+Math.abs(Airplane1.getAltitude-Airplane3.getAltitude));
        System.out.println("The difference in height between Airplane 2 and Airplane 3 is"+Math.abs(Airplane2.getAltitude-Airplane3.getAltitude));
    }
}