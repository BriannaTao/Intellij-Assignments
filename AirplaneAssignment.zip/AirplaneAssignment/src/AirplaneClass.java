public class AirplaneClass {
    private String callSign;
    private double distance;
    private int direction;
    private int altitude;


    public AirplaneClass(){
        callSign = "AAA01";
        distance = 1.0;
        direction = 0;
        altitude = 0;
    }
    public AirplaneClass(String callParam, double distanceParam, int directionParam, int altitudeParam){
        callSign = callParam;
        distance = Math.abs(distanceParam);
        direction = directionParam % 360;
        altitude = Math.abs(altitudeParam);
    }

    public void  move(double distance, int direction){
        distance += distance;
        direction = direction;
        System.out.println("The Airplane is " +distance+ " miles from the tower with a bearing of" +direction+ "degrees")
    }


    public void gainAltitude(){
    altitude += 1000;
    System.out.println(altitude);
    }


    public void loseAltitude(){
        altitude -= 1000;
        if (altitude<0)
            altitude = 0;
    }

    public int getAltitude(){
        return altitude;
    }

    public double getDistance(){
        return distance;
    }

    public String toString(){
        String sentences = callSign + " - " + distance + " miles away at bearing " + direction + ",altitude" + altitude + " feet.";
        return sentences;
    }

    public double distanceTo(Airplane other){
        return(other.distance-distance);

    }
}
