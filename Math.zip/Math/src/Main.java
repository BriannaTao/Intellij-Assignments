// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.

public class Main {
    public static void main(String[] args) {


        int num1 = 10;
        double dub1 = 23.24;
        double dub2 = 13.77;
        // Getting absolute value of an integer
        System.out.println(Math.abs(num1));
        double solution = Math.abs(num1) + Math.abs(dub1);


        // Raise a number to an exponent
        double power = Math.pow(num1, 2);




        // Square root of a double
        double root = Math.sqrt(25);


        //Random function
        System.out.println((int) (Math.random() * 10) );


        //((int) (Math.random () * (max-min+1)) + min
        // This formula gives us a random number between max and min

        System.out.println ((int) (Math.random() * (36-24)+1)+24) ;


    }
}


